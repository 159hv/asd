# GovinfoCheckSystemV1

## 项目结构

- `app/`: 应用程序代码
- `migrations/`: 数据库迁移文件
- `static/`: 静态文件 (CSS, JS, Images)
- `templates/`: 模板文件
- `docs/`: 文档
- `requirements/`: 依赖文件
- `tools/`: 工具脚本
- `.env/`: 环境变量配置
